<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 Mark Hamstra Web Development <support@modmore.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
',
    'readme' => 'MagicPreview for MODX
---------------------

MagicPreview adds a _Magical_ Preview button to the resources panel which will
show you, without actually saving the resource, a real preview of a resource.

It also has responsive breakpoints, so you can preview your page on various widths.
',
    'changelog' => 'MagicPreview 1.2.1-pl
---------------------
Released on 2021-11-29

- Make loading of required processor files more efficient by using the full path. [#17]

MagicPreview 1.2.0-pl
---------------------
Released on 2021-11-19

- Introduce compatibility for MODX 3.

MagicPreview 1.1.1-pl
---------------------
Released on 2021-11-16

- Make sure OnResourceMagicPreview event has a service set

MagicPreview 1.1.0-pl
---------------------
Released on 2021-10-02

- Fix view button not working after clicking on the preview button
- Add OnResourceMagicPreview event so other extras such as ContentBlocks can hook in when using the preview button.
- Fix system fonts used in the preview, did not apply on Windows (among others)

MagicPreview 1.0.1-pl
---------------------
Released on 2018-12-18

- Add loading animation [#6]
- Rewrite CSS to BEM standards, reduce header size [#5]
- Add version-based cache busting to js and css files

MagicPreview 1.0.0-pl
---------------------
Released on 2018-12-17

- First magical release!
',
    'setup-options' => 'magicpreview-1.2.1-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c074b5c2518427519b289d6a28aa3635',
      'native_key' => 'magicpreview',
      'filename' => 'modNamespace/ccacee161758341cf5777a0f7b0457cf.vehicle',
      'namespace' => 'magicpreview',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '2f3f6c2033e3b414a5869087dc0c9b18',
      'native_key' => '2f3f6c2033e3b414a5869087dc0c9b18',
      'filename' => 'xPDOFileVehicle/877861ef8e8d1c8c4cb66315872adfd8.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c10ff6a6b4f42fe70e49f873731dabae',
      'native_key' => 'c10ff6a6b4f42fe70e49f873731dabae',
      'filename' => 'xPDOFileVehicle/f294270587b406be6a7893cb7d022378.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '14e97abd457d46a8f88996e0f5c97e95',
      'native_key' => 1,
      'filename' => 'modPlugin/9150a34e64cafbd86f4dec5cf328a0f9.vehicle',
      'namespace' => 'magicpreview',
    ),
  ),
);