<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 Mark Hamstra Web Development <support@modmore.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
',
    'readme' => 'MagicPreview for MODX
---------------------

MagicPreview adds a _Magical_ Preview button to the resources panel which will
show you, without actually saving the resource, a real preview of a resource.

It also has responsive breakpoints, so you can preview your page on various widths.
',
    'changelog' => 'MagicPreview 1.1.1-pl
---------------------
Released on 2021-11-16

- Make sure OnResourceMagicPreview event has a service set

MagicPreview 1.1.0-pl
---------------------
Released on 2021-10-02

- Fix view button not working after clicking on the preview button
- Add OnResourceMagicPreview event so other extras such as ContentBlocks can hook in when using the preview button.
- Fix system fonts used in the preview, did not apply on Windows (among others)

MagicPreview 1.0.1-pl
---------------------
Released on 2018-12-18

- Add loading animation [#6]
- Rewrite CSS to BEM standards, reduce header size [#5]
- Add version-based cache busting to js and css files

MagicPreview 1.0.0-pl
---------------------
Released on 2018-12-17

- First magical release!
',
    'setup-options' => 'magicpreview-1.1.1-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c2515c532c6f7d9a9b8646453f08d855',
      'native_key' => 'magicpreview',
      'filename' => 'modNamespace/73a2e9f3a72359a734891db997c1c9c2.vehicle',
      'namespace' => 'magicpreview',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '6705be52f979b6c7f9db337721d0e5a3',
      'native_key' => '6705be52f979b6c7f9db337721d0e5a3',
      'filename' => 'xPDOFileVehicle/e1374da43e4be38d6d96fbf797017bc6.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8d004d0f53cd09959812ec9b57b0cced',
      'native_key' => '8d004d0f53cd09959812ec9b57b0cced',
      'filename' => 'xPDOFileVehicle/83793e0db22f0060b6459f3bad6d6ff6.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'bfb62500264410202c04bf73974190d1',
      'native_key' => 1,
      'filename' => 'modPlugin/1042503a0d35ac5d6133e2aebefec2a0.vehicle',
      'namespace' => 'magicpreview',
    ),
  ),
);