<?php
$_lang['magicpreview'] = 'Magisk forhåndsvisning';
$_lang['magicpreview.preview'] = 'Forhåndsvisning af ';
$_lang['magicpreview.preparing_preview'] = 'Forbereder din forhåndsvisning...';

$_lang['magicpreview.bp_full'] = 'Fuld størrelse';
$_lang['magicpreview.bp_desktop'] = 'Desktop';
$_lang['magicpreview.bp_tablet'] = 'Tablet';
$_lang['magicpreview.bp_mobile'] = 'Mobil';
