<?php
$_lang['magicpreview'] = 'Magic Preview';
$_lang['magicpreview.preview'] = 'Preview for ';
$_lang['magicpreview.preparing_preview'] = 'Preparing your preview...';

$_lang['magicpreview.bp_full'] = 'Full';
$_lang['magicpreview.bp_desktop'] = 'Desktop';
$_lang['magicpreview.bp_tablet'] = 'Tablet';
$_lang['magicpreview.bp_mobile'] = 'Mobile';
