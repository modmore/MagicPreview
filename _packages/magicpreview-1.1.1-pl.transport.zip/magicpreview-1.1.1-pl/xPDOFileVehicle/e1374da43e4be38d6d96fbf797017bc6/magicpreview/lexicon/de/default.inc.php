<?php
$_lang['magicpreview'] = 'Magische Vorschau';
$_lang['magicpreview.preview'] = 'Vorschau für ';
$_lang['magicpreview.preparing_preview'] = 'Ihre Vorschau wird vorbereitet...';
$_lang['magicpreview.bp_full'] = 'Volle Breite';
$_lang['magicpreview.bp_desktop'] = 'Desktop';
$_lang['magicpreview.bp_tablet'] = 'Tablet';
$_lang['magicpreview.bp_mobile'] = 'Mobil';
