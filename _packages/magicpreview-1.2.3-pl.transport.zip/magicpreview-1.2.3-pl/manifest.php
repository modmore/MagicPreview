<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2018 Mark Hamstra Web Development <support@modmore.com>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
',
    'readme' => 'MagicPreview for MODX
---------------------

MagicPreview adds a _Magical_ Preview button to the resources panel which will
show you, without actually saving the resource, a real preview of a resource.

It also has responsive breakpoints, so you can preview your page on various widths.
',
    'changelog' => 'MagicPreview 1.2.2-pl
---------------------
Released on 2022-06-02

- Fixed a fatal error that would sometimes occur when loading a preview (thanks to @pbowyer) [#24]
- Replaced the title link with a close button.

MagicPreview 1.2.1-pl
---------------------
Released on 2021-11-29

- Make loading of required processor files more efficient by using the full path. [#17]

MagicPreview 1.2.0-pl
---------------------
Released on 2021-11-19

- Introduce compatibility for MODX 3.

MagicPreview 1.1.1-pl
---------------------
Released on 2021-11-16

- Make sure OnResourceMagicPreview event has a service set

MagicPreview 1.1.0-pl
---------------------
Released on 2021-10-02

- Fix view button not working after clicking on the preview button
- Add OnResourceMagicPreview event so other extras such as ContentBlocks can hook in when using the preview button.
- Fix system fonts used in the preview, did not apply on Windows (among others)

MagicPreview 1.0.1-pl
---------------------
Released on 2018-12-18

- Add loading animation [#6]
- Rewrite CSS to BEM standards, reduce header size [#5]
- Add version-based cache busting to js and css files

MagicPreview 1.0.0-pl
---------------------
Released on 2018-12-17

- First magical release!
',
    'setup-options' => 'magicpreview-1.2.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '149d7437f162c5e863cfcb360b944f7c',
      'native_key' => 'magicpreview',
      'filename' => 'modNamespace/4ecff40a58f1b9cf19a13771f9dbb4fd.vehicle',
      'namespace' => 'magicpreview',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1d84270e51a74cff04b475678f93ff32',
      'native_key' => '1d84270e51a74cff04b475678f93ff32',
      'filename' => 'xPDOFileVehicle/e8dcf822b8e4d32ed4e3597c08ddb196.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5b8e9eca222d371d5aca815c972137ea',
      'native_key' => '5b8e9eca222d371d5aca815c972137ea',
      'filename' => 'xPDOFileVehicle/5da9c3c653b6d9cb7f92ff272e8f53a0.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'd5e54f508e86132ca08feafc8e5cb751',
      'native_key' => 1,
      'filename' => 'modPlugin/464cce864d841b0d8e60e188f8ad7474.vehicle',
      'namespace' => 'magicpreview',
    ),
  ),
);